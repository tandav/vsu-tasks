package edu.vsu;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static java.nio.file.StandardOpenOption.APPEND;

public class Multiplier {
    public static int[][] multiply(int[][] A, int[][] B) {
        int threadsN = 4;
        if (A.length == 0 || A[0].length == 0 || B.length == 0 || B[0].length == 0) { throw new ArithmeticException("zero dimension matrix"); }
        if (threadsN == 0) { throw new ArithmeticException("threadsN should be > 0"); }
        if (A[0].length != B.length) { throw new ArithmeticException("A[0].length != B.length"); }

        int n = A.length;    // result rows
        int m = A[0].length;
        int p = B[0].length; // result cols

        int[][] C = new int[n][p];

        int rowsPerThread = n / threadsN;
        List<Thread> threads = new ArrayList<>();

        for (int offset = 0; offset < rowsPerThread * threadsN; offset += rowsPerThread) {
            int finalOffset = offset;

            threads.add(new Thread(() -> {
                for (int i = finalOffset; i < finalOffset + rowsPerThread; i++) {
                    for (int j = 0; j < p; j++) {
                        for (int k = 0; k < m; k++) {
                            C[i][j] += A[i][k] * B[k][j];
                        }
                    }
                }
            }));
        }

        threads.forEach(Thread::start);
        threads.forEach(thread -> {
            try { thread.join(); }
            catch (InterruptedException e) { System.out.println("waiting until threads complete their computations..."); }
        });


        // non-parallel calculation of rest or if number of threads more than number of rows in result matrix
        if (n % threadsN != 0) {
            for (int i = threadsN * rowsPerThread; i < n; i++) {
                for (int j = 0; j < p; j++) {
                    for (int k = 0; k < m; k++) {
                        C[i][j] += A[i][k] * B[k][j];
                    }
                }
            }
        }

        return C;
    }

    public static int[][] multiply(int[][] A, int[][] B, int threadsN) {

        if (A.length == 0 || A[0].length == 0 || B.length == 0 || B[0].length == 0) { throw new ArithmeticException("zero dimension matrix"); }
        if (threadsN == 0) { throw new ArithmeticException("threadsN should be > 0"); }
        if (A[0].length != B.length) { throw new ArithmeticException("A[0].length != B.length"); }

        int n = A.length;    // result rows
        int m = A[0].length;
        int p = B[0].length; // result cols

        int[][] C = new int[n][p];

        int rowsPerThread = n / threadsN;
        List<Thread> threads = new ArrayList<>();

        for (int offset = 0; offset < rowsPerThread * threadsN; offset += rowsPerThread) {
            int finalOffset = offset;

            threads.add(new Thread(() -> {
                for (int i = finalOffset; i < finalOffset + rowsPerThread; i++) {
                    for (int j = 0; j < p; j++) {
                        for (int k = 0; k < m; k++) {
                            C[i][j] += A[i][k] * B[k][j];
                        }
                    }
                }
            }));
        }

        threads.forEach(Thread::start);
        threads.forEach(thread -> {
            try { thread.join(); }
            catch (InterruptedException e) { System.out.println("waiting until threads complete their computations..."); }
        });


        // non-parallel calculation of rest or if number of threads more than number of rows in result matrix
        if (n % threadsN != 0) {
            for (int i = threadsN * rowsPerThread; i < n; i++) {
                for (int j = 0; j < p; j++) {
                    for (int k = 0; k < m; k++) {
                        C[i][j] += A[i][k] * B[k][j];
                    }
                }
            }
        }

        return C;
    }

    public static int[][] randomMatrix(int rows, int cols) {
        int[][] matrix = new int[rows][cols];
        Random rand = new Random();
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                matrix[i][j] = rand.nextInt(100);
        return matrix;
    }

    public static void printMatrix(int[][] M) {
        System.out.println();

        for (int[] row : M) {
            for (int el: row) {
                System.out.print(el + "\t");
            }
            System.out.println();
        }

        System.out.println();
    }

    public static void benchmark() throws IOException {
        // clear file's content
        Files.write(Paths.get("out.tsv"), "".getBytes());

        for (int N = 16; N <= 256; N += 16) {
            int[][] A = randomMatrix(N, N);
            int[][] B = randomMatrix(N, N);
            for (int threads = 1; threads <= 16; threads++) {
                long startTime = System.currentTimeMillis();
                int[][] C = multiply(A, B, threads);
                long elapsedTime = System.currentTimeMillis() - startTime;
                System.out.print(elapsedTime + "\t");
                Files.write(Paths.get("out.tsv"), (elapsedTime + "\t").getBytes(), APPEND);
            }
            System.out.println();
            Files.write(Paths.get("out.tsv"), "\n".getBytes(), APPEND);
        }
    }
}
