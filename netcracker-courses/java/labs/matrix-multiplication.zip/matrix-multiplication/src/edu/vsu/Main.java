package edu.vsu;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) {

        int[][] A = Multiplier.randomMatrix(10, 4);
        int[][] B = Multiplier.randomMatrix(4, 12);
        int[][] C = Multiplier.multiply(A, B);

        Multiplier.printMatrix(A);
        Multiplier.printMatrix(B);
        Multiplier.printMatrix(C);

//        multiplier.benchmark();
    }


}
