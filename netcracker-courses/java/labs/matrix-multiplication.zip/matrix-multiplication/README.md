# TODO
- compare w/ sequential version
- make image chart:
    - X: size of square matrix
    - Y: number of threads